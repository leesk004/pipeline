'''
import R8_MaxtoMaya.R8_ani_fbx_importer as R8_ani_fbx_importer
from imp import reload
reload(R8_ani_fbx_importer)
R8_ani_fbx_importer.show_ui()
'''
import os
import json
from maya import cmds
import maya.OpenMayaUI as omui

try:
    from PySide6 import QtWidgets, QtCore
    from shiboken6 import wrapInstance
except:
    from PySide2 import QtWidgets, QtCore
    from shiboken2 import wrapInstance

import R8_MaxtoMaya.R8_ani_skeleton_match as R8_ani_skeleton_match
from importlib import reload
reload(R8_ani_skeleton_match)

impoterName = 'Ani FBX Importer'
default_folder_path = r'D:\\LOP\\LOP\\GraphicResource\\Content\\ArtAsset\\CH\\MOB\\PuppetKing\\Animset\\Action\\P1'

# Maya의 메인 윈도우 가져오기
def get_maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)

# 선택된 FBX 파일 경로를 저장할 리스트
fbx_file_list = []

# 프로젝트 폴더 경로
project_folder = 'None'

# JSON 파일 경로
json_file_path = os.path.join('C:\\', 'ani_fbx_set.json')

# 선택된 폴더 내의 FBX 파일을 리스트에 추가하는 함수
def add_fbx_files_from_folder(folder_path, file_list_widget):
    global fbx_file_list
    if folder_path and os.path.isdir(folder_path):
        fbx_files = [f for f in os.listdir(folder_path) if f.endswith('.fbx') or f.endswith('.FBX')]
        # os.path.join(folder_path, f)
        fbx_file_list.extend(fbx_files)
        file_list_widget.clear()
        file_list_widget.addItems(fbx_files)

# 선택된 파일을 Maya에 레퍼런스로 불러오는 함수
def reference_fbx_file(file_path):
    if file_path:
        file_name = os.path.basename(file_path).split('.')[0]  # Extract filename without extension
        cmds.file(file_path, reference=True, namespace=file_name)
        # pm.system.createReference(file_path, namespace=file_name)

# 선택된 파일을 Maya에 임포트하는 함수
def import_fbx_file(file_path):
    if file_path:
        file_name = os.path.basename(file_path).split('.')[0]  # Extract filename without extension
        cmds.file(file_path, i=True, type='FBX', namespace=file_name)
        # pm.importFile(file_path, type='FBX', i=True, namespace=file_name)

def time_change_set():
    '''
    game: 15 fps
    film: 24 fps
    pal: 25 fps
    ntsc: 30 fps
    show: 48 fps
    palf: 50 fps
    ntscf: 60 fps
    '''
    # 시간 단위를 'ntscf'으로 설정 (60fps)
    cmds.currentUnit(time='ntscf')
        
# UI 
class FbxImporterUI(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(FbxImporterUI, self).__init__(parent)
        self.setWindowTitle(impoterName)
        self.resize(600, 500)  # Adjusted width and height
        
        self.layout = QtWidgets.QVBoxLayout(self)
        
        hbox_layout_folder = QtWidgets.QHBoxLayout()
        self.path_line_edit = QtWidgets.QLineEdit()
        self.load_json()
        hbox_layout_folder.addWidget(self.path_line_edit)  
        # Add a "Set" button
        self.set_button = QtWidgets.QPushButton("Set Folder")
        self.set_button.clicked.connect(self.set_folder)
        hbox_layout_folder.addWidget(self.set_button)  

        self.layout.addLayout(hbox_layout_folder)
        
        # Scroll area for file list widget
        scroll_area = QtWidgets.QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFocusPolicy(QtCore.Qt.NoFocus)

        self.file_list_widget = QtWidgets.QListWidget()
        self.file_list_widget.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.file_list_widget.itemDoubleClicked.connect(self.file_double_clicked)
        font = self.file_list_widget.font()
        font.setPointSize(10)  # 원하는 폰트 크기로 설정
        self.file_list_widget.setFont(font)
        # 우측 클릭 윈도우 검색 열기 추가
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.open_context_menu)

        scroll_area.setWidget(self.file_list_widget)
        self.layout.addWidget(scroll_area)
        
        hbox_layout_buttons = QtWidgets.QHBoxLayout()
        
        self.import_button = QtWidgets.QPushButton('1. Reference Selected FBX Files')
        self.import_button.setFixedHeight(30)
        self.import_button.setStyleSheet('background-color: lightgrey; color: black;')
        self.import_button.clicked.connect(self.reference_selected_files)
        hbox_layout_buttons.addWidget(self.import_button)

        self.ref_button = QtWidgets.QPushButton('Reference Editor')
        self.ref_button.setFixedHeight(30)
        self.ref_button.clicked.connect(self.reference_editor_open)
        hbox_layout_buttons.addWidget(self.ref_button)
        
        hbox_layout_buttons2 = QtWidgets.QHBoxLayout()
        hbox_layout_buttons2_1 = QtWidgets.QHBoxLayout()
        self.match_button = QtWidgets.QPushButton('2. SKeleton Match')
        self.match_button.setFixedHeight(30)
        self.match_button.setStyleSheet('background-color: lightgrey; color: black;')
        self.match_button.clicked.connect(self.skeleton_match_func)
        hbox_layout_buttons2_1.addWidget(self.match_button)
        hbox_layout_buttons2.addLayout(hbox_layout_buttons2_1)
        # 체크박스 생성
        hbox_layout_buttons2_2 = QtWidgets.QHBoxLayout()
        self.frontX_checkbox = QtWidgets.QCheckBox(' FrontX ')
        self.frontZ_checkbox = QtWidgets.QCheckBox(' FrontZ ')
        hbox_layout_buttons2_2.addWidget(self.frontX_checkbox)
        hbox_layout_buttons2_2.addWidget(self.frontZ_checkbox)
        # 체크박스 상태 변경 시 슬롯 연결
        self.frontX_checkbox.stateChanged.connect(self.on_frontX_changed)
        self.frontZ_checkbox.stateChanged.connect(self.on_frontZ_changed)
        hbox_layout_buttons2.addLayout(hbox_layout_buttons2_2)
        
        hbox_layout_buttons3 = QtWidgets.QHBoxLayout()
        self.bake_button = QtWidgets.QPushButton('3. FK Control Bake')
        self.bake_button.setFixedHeight(30)
        self.bake_button.setStyleSheet('background-color: lightgrey; color: black;')
        self.bake_button.clicked.connect(self.control_bake_func)
        self.delete_key_button = QtWidgets.QPushButton('Delete Control Bake')
        self.delete_key_button.setFixedHeight(30)
        self.delete_key_button.clicked.connect(self.delete_key_func)
        
        hbox_layout_buttons3.addWidget(self.bake_button)
        hbox_layout_buttons3.addWidget(self.delete_key_button)
        
        self.layout.addLayout(hbox_layout_buttons)
        self.layout.addLayout(hbox_layout_buttons2)
        self.layout.addLayout(hbox_layout_buttons3)

        self.frontX_checkbox.setChecked(True)
        
        if project_folder:
            add_fbx_files_from_folder(project_folder, self.file_list_widget)
    
    def on_frontX_changed(self, state):
        if state:
            self.frontZ_checkbox.setChecked(False)  # frontZ 체크박스 해제
        else:
            self.frontZ_checkbox.setChecked(True)  # frontZ 체크박스 해제
            
    def on_frontZ_changed(self, state):
        if state:
            self.frontX_checkbox.setChecked(False)  # frontX 체크박스 해제
        else:
            self.frontX_checkbox.setChecked(True)  # frontX 체크박스 해제
            
    def open_context_menu(self, position):
        menu = QtWidgets.QMenu()
        open_in_explorer_action = menu.addAction("Open in Explorer")
        open_in_explorer_action.triggered.connect(self.open_in_explorer)
        menu.exec_(self.mapToGlobal(position))
    
    def open_in_explorer(self):
        folder_path = self.path_line_edit.text()
        selected_items = self.file_list_widget.selectedItems()
        if selected_items:
            item = selected_items[0]
            file_path = folder_path + '/' + item.text()
            if os.path.exists(file_path):
                folder_path = os.path.dirname(file_path)
                os.startfile(folder_path)
                        
    def control_bake_func(self):
        R8_ani_skeleton_match.control_bake()
    
    def skeleton_match_func(self):
        frontX_v = self.frontX_checkbox.isChecked()
        if frontX_v:
            R8_ani_skeleton_match.skeleton_control_match('frontX')
        else:
            R8_ani_skeleton_match.skeleton_control_match('frontZ')
            
    def reference_editor_open(self):
        cmds.ReferenceEditor()
    
    def delete_key_func(self):
        R8_ani_skeleton_match.delete_key_control()
    
    def file_double_clicked(self, item):
        if item:
            dialog = ReferenceImportDialog(self)
            if dialog.exec_() == QtWidgets.QDialog.Accepted:
                # Handle reference or import operations based on user selection
                if dialog.result == 'Reference':
                    self.reference_selected_files()
                elif dialog.result == 'Import':
                    self.import_selected_files()                    
        
    def set_folder(self):
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 'Set Folder', self.path_line_edit.text())
        if folder_path:
            self.path_line_edit.setText(folder_path)
            add_fbx_files_from_folder(folder_path, self.file_list_widget)
            self.save_json(folder_path)
            
    def select_file(self):
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select File", "", "FBX Files (*.fbx)")
        if file_path:
            import_fbx_file(file_path)
            
    def reference_selected_files(self):
        prj_path = self.path_line_edit.text()
        for item in self.file_list_widget.selectedItems():
            reference_fbx_file(f'{prj_path}/{item.text()}')
        time_change_set()
            
    def import_selected_files(self):
        prj_path = self.path_line_edit.text()
        for item in self.file_list_widget.selectedItems():
            # print (f'{prj_path}/{item.text()}')
            import_fbx_file(f'{prj_path}/{item.text()}')
        time_change_set()
        
    def load_json(self):
        global project_folder
        if os.path.exists(json_file_path):
            with open(json_file_path, 'r') as file:
                data = json.load(file)
                if 'project_folder' in data:
                    project_folder = data['project_folder']
                    self.path_line_edit.setText(project_folder)
        elif os.name == 'nt':  # Check if the operating system is Windows
            self.path_line_edit.setText(default_folder_path)
            
    def save_json(self, folder_path):
        data = {'project_folder': folder_path}
        with open(json_file_path, 'w') as file:
            json.dump(data, file)


class ReferenceImportDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(ReferenceImportDialog, self).__init__(parent)
        self.setWindowTitle('Reference or Import')
        self.setFixedSize(300, 100)

        layout = QtWidgets.QVBoxLayout(self)

        self.reference_button = QtWidgets.QPushButton('Reference')
        self.reference_button.clicked.connect(self.reference_clicked)
        layout.addWidget(self.reference_button)

        self.import_button = QtWidgets.QPushButton('Import')
        self.import_button.clicked.connect(self.import_clicked)
        layout.addWidget(self.import_button)

        self.cancel_button = QtWidgets.QPushButton('Cancel')
        self.cancel_button.clicked.connect(self.reject)
        layout.addWidget(self.cancel_button)

        self.result = None

    def reference_clicked(self):
        self.result = 'Reference'
        self.accept()       

    def import_clicked(self):
        self.result = 'Import'
        self.accept()

# 기존 창을 닫고 새로운 UI 생성 호출
def show_ui():
    maya_main_window = get_maya_main_window()
    
    # 기존 창 닫기
    for widget in maya_main_window.findChildren(QtWidgets.QWidget):
        if widget.windowTitle() == impoterName:
            widget.close()
    
    # 새 UI 생성 및 표시
    ui = FbxImporterUI(parent=maya_main_window)
    ui.show()
    
if __name__ == '__main__':
    show_ui()
