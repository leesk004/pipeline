# import pymel.core as pm
from maya import cmds

SKEL_SET = 'Skeleton_Set'
BAKE_CTRL_SET = 'Bake_Control_Set'
global contList

def skeleton_bindpose(selectObjects, prefix):
    cmds.playbackOptions(min=-10)
    cmds.currentTime(-10)        
    for obj in selectObjects:
        if cmds.objExists(f'{prefix}:{obj}'):
            if obj == 'Root':continue
            tg_obj = f'{prefix}:{obj}'
            for ax in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']:
                tv = cmds.getAttr(f'{obj}.{ax}')
                cmds.setAttr(f'{tg_obj}.{ax}', tv)
                cmds.setKeyframe(f'{tg_obj}.{ax}')
    
# 씬 안에 ":" 프리픽스 이름 가져오기
def get_colon_prefixes():
    all_objects = cmds.ls()
    prefixes = set()

    for obj in all_objects:
        name_parts = obj.split(':')
        if len(name_parts) > 1:
            prefixes.add(name_parts[0])

    return prefixes

def bake_animation(controls, startFrame, endFrame):
    cmds.bakeResults(controls, simulation=True, t=(startFrame, endFrame),
                     sampleBy=1, oversamplingRate=1, disableImplicitControl=True,
                     preserveOutsideKeys=True, sparseAnimCurveBake=False, removeBakedAttributeFromLayer=False,
                     removeBakedAnimFromLayer=False, bakeOnOverrideLayer=False, minimizeRotation=True, controlPoints=False, shape=True)

def joint_Exists(joints, pre_):
    joint_list = []
    for jnt in joints:
        if cmds.objExists(f'{pre_}:{jnt}'):
            joint_list.append(jnt)
    return joint_list

def skeleton_control_match(frontAxis='frontX'):
    global contList
    # 모든 콜론 프리픽스를 가져와 출력합니다.
    prefix = list(get_colon_prefixes())[0]
    try:
        set_node = SKEL_SET
        members = cmds.sets(set_node, q=True) 
        selectObjects = joint_Exists(members, prefix)
        cmds.select(clear=True)
        if not cmds.objExists('root_grp'):
            cmds.group(em=True, name='root_grp')
        if not cmds.listRelatives(f'{prefix}:Root', p=True):
            cmds.parent(f'{prefix}:Root', 'root_grp')
        if frontAxis == 'frontX':
            if cmds.objExists('MainExtra2'):
                cmds.setAttr('MainExtra2.rotateY', 90)
            cmds.setAttr('root_grp.rotateY', 0)
        else:
            if cmds.objExists('MainExtra2'):
                cmds.setAttr('MainExtra2.rotateY', 0)
            cmds.setAttr('root_grp.rotateY', -90)   
        skeleton_bindpose(selectObjects, prefix)
        
    except Exception as e:
        print (f'오류가 발생했습니다. {e}')
        return

    contList = []
    aniJointList = []

    for obj in selectObjects:
        parent_constraints = cmds.listConnections(obj, type='parentConstraint')
        if not parent_constraints:
            continue
        
        target_loc = cmds.parentConstraint(parent_constraints[0], query=True, targetList=True)
        
        if target_loc:
            # Check if the rotate attribute is connected
            if cmds.getAttr(target_loc[0] + '.rotate'):
                aniJoint = f'{prefix}:{obj}'
                if cmds.objExists(aniJoint):
                    aniJointList.append(aniJoint)    
                locCon = cmds.listConnections(target_loc[0] + '.rotate')[0]
                contList.append(cmds.listRelatives(f'{locCon}_grp', parent=True)[0])
                
    # print (contList)            
    if contList:
        # 새로운 셋 생성
        set_name = BAKE_CTRL_SET
        # 기존 'Bake_Control_Set' 이 있으면 지우기
        if cmds.objExists(set_name):cmds.delete(set_name)
        cmds.sets(contList, name=set_name)  
        cmds.select(clear=True)  
        
        # Key가 들어간 드라이브 조인트, 드리븐 컨트롤러 컨스트레인 연결     
        for j, c in zip(aniJointList, contList):
            print(j, c)
            try:
                if not cmds.objExists(c):
                    print(f"경고: 컨트롤러 {c}가 존재하지 않습니다. 건너뜁니다.")
                    continue
                    
                c_ro = cmds.getAttr(f'{c}.rotateOrder')
                ctlLoc = cmds.spaceLocator(p=(0, 0, 0), name=f'{c}_ctl')
                cmds.setAttr(f'{ctlLoc[0]}.rotateOrder', c_ro)
                ctlLocGrp = cmds.group(em=True, name=f'{ctlLoc[0]}_grp')
                cmds.parent(ctlLoc, ctlLocGrp)
                cmds.delete(cmds.pointConstraint(c, ctlLocGrp, mo=False))
                cmds.delete(cmds.orientConstraint(c, ctlLocGrp, mo=False))
                cmds.parent(ctlLocGrp, j)
                cmds.select(clear=True)
                
                if cmds.getAttr(c + '.tx', keyable=True):
                    cmds.parentConstraint(ctlLoc, c, mo=True)          
                if cmds.getAttr(c + '.sx', keyable=True):
                    cmds.scaleConstraint(ctlLoc, c, mo=True)
            except Exception as e:
                print(f"컨트롤러 {c} 처리 중 오류 발생: {str(e)}")
                continue

def control_bake():
    global contList
    cmds.playbackOptions(ast=0, min=0)
    cmds.currentTime(0) 
    startFrame = cmds.playbackOptions(q=True, minTime=True)
    endFrame = cmds.playbackOptions(q=True, maxTime=True)
    bake_animation(contList, startFrame, endFrame)

def unload_reference_file():
    # 선택된 객체 가져오기
    refs = cmds.ls(type='reference')
    # 선택된 객체가 있는지 확인
    if not refs:
        print("선택된 객체가 없습니다.")
    else:
        for ref in refs:
            # 레퍼런스 노드인지 확인
            if cmds.nodeType(ref) == 'reference':
                # 레퍼런스 언로드
                # 특정 레퍼런스 노드 언로드
                cmds.file(referenceNode=ref, removeReference=True)  
                print(f"{ref} 레퍼런스 노드가 unload 되었습니다.")
            else:
                print(f"{ref}는 레퍼런스 노드가 아닙니다.")
            
def delete_conatraint(controllers):
    for cont in controllers:
        # 객체에 연결된 모든 제약 노드 찾기
        constraints = set(cmds.listConnections(cont, type='constraint'))
        constraints = list(constraints)
        constraints = [const for const in constraints if cont in const]
        if constraints:
            for constraint in constraints:
                # 제약 노드 삭제
                cmds.delete(constraint)
            print(f"{cont}에 연결된 제약 노드가 삭제되었습니다.")
        else:
            print(f"{cont}에 연결된 제약 노드가 없습니다.")
                          
def delete_key_control():
    try:
        members = cmds.sets(BAKE_CTRL_SET, q=True) 
        cmds.select(members)
        controllers = cmds.ls(sl=True)
        cmds.select(clear=True)
        delete_conatraint(controllers) 
        
        attrList = ['translateX', 'translateY', 'translateZ', 
                    'rotateX', 'rotateY', 'rotateZ']
        attrList2 = ['scaleX', 'scaleY', 'scaleZ']
        for cont in controllers:
            attributes = cmds.listAttr(cont, keyable=True)
            # 각 속성에 대해 키프레임 확인
            for attr in attributes:
                # 키프레임이 있는지 확인
                keyframes = cmds.keyframe(f'{cont}.{attr}', query=True)
                if keyframes:
                    cmds.cutKey(f'{cont}.{attr}')

                if attr in attrList:
                    cmds.setAttr(f'{cont}.{attr}', 0)
                elif attr in attrList2:
                    cmds.setAttr(f'{cont}.{attr}', 1)  
                                     
        unload_reference_file()  
        if cmds.objExists('MainSystem'):
            cmds.setAttr('MainSystem.rotateY', 0)                   
        if cmds.objExists('root_grp'):
            cmds.delete('root_grp')                          
        cmds.currentTime(0)  
        parent_del = cmds.ls(type='fosterParent')
        if parent_del:
            cmds.delete(parent_del)          
    except:    
        pass   
    
if __name__ == '__main__':
    skeleton_control_match()
    control_bake()
